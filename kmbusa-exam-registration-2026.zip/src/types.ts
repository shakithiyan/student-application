
export interface StudentRegistration {
  id?: string;
  fullName: string;
  stream: string;
  batch: string;
  schoolName: string;
  gender: 'male' | 'female';
  contactNumber: string;
  nicNumber: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: number;
}

export const STREAMS = ['Biological Science', 'Physics Science'];
export const BATCHES = ['2024', '2025', '2026', '2027'];
export const GENDERS = ['male', 'female'] as const;
