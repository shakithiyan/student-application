import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GraduationCap } from 'lucide-react';

interface IntroProps {
  onComplete: () => void;
}

export default function Intro({ onComplete }: IntroProps) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    const timers = [
      setTimeout(() => setStep(1), 500), // Show Logo
      setTimeout(() => setStep(2), 1500), // Show Text
      setTimeout(() => setStep(3), 3000), // Fade Out
    ];

    return () => timers.forEach(clearTimeout);
  }, []);

  useEffect(() => {
    if (step === 3) {
      const timer = setTimeout(onComplete, 1000);
      return () => clearTimeout(timer);
    }
  }, [step, onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-blue-900 overflow-hidden">
      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="logo"
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 1.2, opacity: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="flex flex-col items-center"
          >
            <div className="w-48 h-48 md:w-64 md:h-64 bg-white rounded-full flex items-center justify-center shadow-2xl p-4 border-4 border-blue-400/20">
              <GraduationCap className="w-24 h-24 md:w-32 md:h-32 text-blue-900" />
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div
            key="text"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center px-6"
          >
            <motion.h1 
              className="text-5xl md:text-7xl font-bold text-white mb-4 tracking-tighter"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              KMBUSA
            </motion.h1>
            <motion.p 
              className="text-xl md:text-2xl text-blue-200 font-medium max-w-2xl mx-auto leading-relaxed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              Kilinochchi Maths Bio University Students' Association
            </motion.p>
            <motion.div 
              className="mt-8 h-1 bg-blue-400/30 rounded-full overflow-hidden w-64 mx-auto"
              initial={{ width: 0 }}
              animate={{ width: 256 }}
              transition={{ delay: 0.5, duration: 1.5 }}
            >
              <motion.div 
                className="h-full bg-blue-300"
                animate={{ x: ["-100%", "100%"] }}
                transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="absolute bottom-12 text-blue-300/50 text-sm font-mono tracking-widest">
        ESTABLISHED 2024
      </div>
    </div>
  );
}
