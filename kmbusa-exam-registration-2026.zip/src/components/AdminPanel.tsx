import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  Users, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Search, 
  Download,
  BarChart3,
  PieChart as PieChartIcon,
  ChevronRight,
  ShieldCheck,
  LogOut
} from 'lucide-react';
import { StudentRegistration, STREAMS, BATCHES } from '../types';
import { formatDate, cn } from '../lib/utils';
import { updateRegistrationStatus } from '../firebase';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from 'recharts';

interface AdminPanelProps {
  registrations: StudentRegistration[];
  onLogout: () => void;
}

const COLORS = ['#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', '#bfdbfe'];

export default function AdminPanel({ registrations, onLogout }: AdminPanelProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [view, setView] = useState<'list' | 'analytics'>('list');

  const filteredData = useMemo(() => {
    return registrations.filter(item => {
      const matchesSearch = item.fullName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            item.nicNumber.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [registrations, searchTerm, statusFilter]);

  const stats = useMemo(() => {
    const total = registrations.length;
    const pending = registrations.filter(r => r.status === 'pending').length;
    const approved = registrations.filter(r => r.status === 'approved').length;
    const rejected = registrations.filter(r => r.status === 'rejected').length;
    return { total, pending, approved, rejected };
  }, [registrations]);

  const analytics = useMemo(() => {
    const genderData = [
      { name: 'Male', value: registrations.filter(r => r.gender === 'male').length },
      { name: 'Female', value: registrations.filter(r => r.gender === 'female').length },
    ];

    const batchData = BATCHES.map(batch => ({
      name: batch,
      count: registrations.filter(r => r.batch === batch).length
    }));

    const streamData = STREAMS.map(stream => ({
      name: stream,
      count: registrations.filter(r => r.stream === stream).length
    }));

    return { genderData, batchData, streamData };
  }, [registrations]);

  return (
    <div className="h-screen w-screen bg-slate-50 flex overflow-hidden font-sans text-slate-800">
      {/* Admin Sidebar */}
      <aside className="hidden lg:flex w-72 bg-slate-900 flex-col p-8 text-white shrink-0 shadow-2xl z-20">
        <div className="flex flex-col items-center mb-10">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg transform -rotate-3 mb-4">
            <ShieldCheck className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-black tracking-tighter">Admin Portal</h1>
          <p className="text-[10px] text-blue-400 mt-2 font-bold uppercase tracking-widest">KMBUSA MANAGEMENT</p>
        </div>

        <nav className="space-y-2 flex-1">
          <button 
            onClick={() => setView('list')}
            className={cn(
              "w-full p-4 rounded-xl transition-all flex items-center justify-between group",
              view === 'list' ? "bg-white/10 text-white" : "text-white/50 hover:bg-white/5 hover:text-white"
            )}
          >
            <div className="flex items-center gap-3">
              <Users className="w-4 h-4" />
              <span className="text-sm font-bold">Applications</span>
            </div>
            {view === 'list' && <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>}
          </button>
          
          <button 
            onClick={() => setView('analytics')}
            className={cn(
              "w-full p-4 rounded-xl transition-all flex items-center justify-between group",
              view === 'analytics' ? "bg-white/10 text-white" : "text-white/50 hover:bg-white/5 hover:text-white"
            )}
          >
            <div className="flex items-center gap-3">
              <BarChart3 className="w-4 h-4" />
              <span className="text-sm font-bold">Analytics</span>
            </div>
            {view === 'analytics' && <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>}
          </button>
        </nav>

        <div className="pt-6 border-t border-white/10">
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 p-4 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl transition-all group"
          >
            <LogOut className="w-4 h-4" />
            <span className="text-sm font-black tracking-tight">Logout</span>
          </button>
        </div>
      </aside>

      {/* Admin Content Area */}
      <main className="flex-1 flex flex-col overflow-y-auto bg-slate-50 relative">
        <header className="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-10">
          <div className="flex items-center gap-4">
             <div className="w-1 h-6 bg-blue-600 rounded-full"></div>
             <h2 className="text-xl font-black text-slate-900 tracking-tight uppercase">
               {view === 'list' ? 'Application Queue' : 'Statistical Overview'}
             </h2>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-2 px-3 py-1 bg-green-50 text-green-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-green-100">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
              Session Active
            </div>
          </div>
        </header>

        <div className="p-8 max-w-[1600px] mx-auto w-full flex flex-col gap-8">
          {/* Stats Bar */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Total', val: stats.total, color: 'blue', icon: Users },
              { label: 'Pending', val: stats.pending, color: 'amber', icon: Clock },
              { label: 'Approved', val: stats.approved, color: 'emerald', icon: CheckCircle },
              { label: 'Rejected', val: stats.rejected, color: 'rose', icon: XCircle },
            ].map((s, i) => (
              <div key={i} className="bg-white p-5 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-5">
                <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center", `bg-${s.color}-50 text-${s.color}-600`)}>
                  <s.icon className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{s.label}</p>
                  <p className="text-2xl font-black text-slate-900 leading-none mt-1">{s.val}</p>
                </div>
              </div>
            ))}
          </div>

          {view === 'list' ? (
            <div className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden flex flex-col">
              {/* Table Toolbar */}
              <div className="p-6 bg-slate-50/50 border-b border-slate-100 flex flex-col lg:flex-row gap-6 justify-between items-center">
                <div className="relative w-full lg:max-w-md group">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-600 transition-colors" />
                  <input 
                    type="text"
                    placeholder="Search applicants..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-medium focus:ring-4 focus:ring-blue-50 outline-none transition-all shadow-sm"
                  />
                </div>
                <div className="flex bg-slate-200/50 p-1 rounded-2xl border border-slate-200/50">
                  {(['all', 'pending', 'approved', 'rejected'] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => setStatusFilter(f)}
                      className={cn(
                        "px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                        statusFilter === f 
                          ? "bg-white text-blue-600 shadow-sm" 
                          : "text-slate-500 hover:text-slate-700"
                      )}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>

              {/* Enhanced Table */}
              <div className="overflow-x-auto min-h-[500px]">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/30">
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Student Information</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Academic Background</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Contact Identity</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Outcome</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Review Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {filteredData.length > 0 ? filteredData.map((item) => (
                      <motion.tr 
                        layout
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        key={item.id} 
                        className="hover:bg-blue-50/40 transition-colors group"
                      >
                        <td className="px-8 py-6">
                          <div className="flex flex-col">
                            <span className="font-black text-slate-900 group-hover:text-blue-600 transition-colors">{item.fullName}</span>
                            <span className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-tight">Reg Date: {formatDate(item.createdAt)}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex flex-col gap-1.5">
                            <span className="text-xs font-black bg-blue-100 text-blue-700 px-2.5 py-1 rounded-lg self-start uppercase tracking-wider">{item.stream}</span>
                            <span className="text-xs font-bold text-slate-500 truncate max-w-[200px]">{item.schoolName}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex flex-col">
                            <span className="text-xs font-black font-mono text-slate-900">{item.nicNumber}</span>
                            <span className="text-xs font-bold text-slate-400 mt-0.5">{item.contactNumber}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6 text-center">
                          <span className={cn(
                            "px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest",
                            item.status === 'approved' && "bg-emerald-50 text-emerald-600 border border-emerald-100",
                            item.status === 'rejected' && "bg-rose-50 text-rose-600 border border-rose-100",
                            item.status === 'pending' && "bg-amber-50 text-amber-600 border border-amber-100"
                          )}>
                            {item.status}
                          </span>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <div className="flex items-center justify-end gap-3 translate-x-4 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 transition-all duration-300">
                            <button
                              onClick={() => updateRegistrationStatus(item.id!, 'approved')}
                              disabled={item.status === 'approved'}
                              className="w-10 h-10 bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white rounded-2xl transition-all shadow-sm border border-emerald-100 flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed active:scale-90"
                            >
                              <CheckCircle className="w-5 h-5" />
                            </button>
                            <button
                              onClick={() => updateRegistrationStatus(item.id!, 'rejected')}
                              disabled={item.status === 'rejected'}
                              className="w-10 h-10 bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white rounded-2xl transition-all shadow-sm border border-rose-100 flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed active:scale-90"
                            >
                              <XCircle className="w-5 h-5" />
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    )) : (
                      <tr>
                        <td colSpan={5} className="px-8 py-20 text-center">
                           <div className="flex flex-col items-center gap-4">
                              <Search className="w-12 h-12 text-slate-200" />
                              <p className="text-slate-400 font-black tracking-tight italic">NO RECORDS MATCHING CRITERIA</p>
                           </div>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Analytics Containers with standard white card styling */}
              <div className="lg:col-span-4 bg-white p-8 rounded-[2rem] shadow-lg border border-slate-100">
                <h3 className="text-sm font-black text-slate-900 mb-8 uppercase tracking-widest flex items-center gap-2">
                   <div className="w-1.5 h-4 bg-blue-600 rounded-full"></div>
                   Gender Distribution
                </h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={analytics.genderData}
                        cx="50%"
                        cy="50%"
                        innerRadius={80}
                        outerRadius={100}
                        paddingAngle={10}
                        dataKey="value"
                      >
                        {analytics.genderData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend verticalAlign="bottom" height={36} wrapperStyle={{ fontSize: '10px', textTransform: 'uppercase', fontWeight: 900 }}/>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="lg:col-span-8 bg-white p-8 rounded-[2rem] shadow-lg border border-slate-100">
                <h3 className="text-sm font-black text-slate-900 mb-8 uppercase tracking-widest flex items-center gap-2">
                   <div className="w-1.5 h-4 bg-blue-600 rounded-full"></div>
                   Academic Stream Performance
                </h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.streamData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} fontWeight={700} />
                      <YAxis axisLine={false} tickLine={false} fontSize={10} fontWeight={700} />
                      <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                      <Bar dataKey="count" fill="#2563eb" radius={[6, 6, 0, 0]} barSize={50} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="lg:col-span-12 bg-white p-8 rounded-[2rem] shadow-lg border border-slate-100">
                <h3 className="text-sm font-black text-slate-900 mb-8 uppercase tracking-widest flex items-center gap-2">
                   <div className="w-1.5 h-4 bg-blue-600 rounded-full"></div>
                   Batch Enrollment Timeline
                </h3>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.batchData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                      <XAxis type="number" axisLine={false} tickLine={false} fontSize={10} fontWeight={700} />
                      <YAxis dataKey="name" type="category" fontSize={12} axisLine={false} tickLine={false} fontWeight={900} />
                      <Tooltip cursor={{fill: '#f8fafc'}} />
                      <Bar dataKey="count" fill="#3b82f6" radius={[0, 6, 6, 0]} barSize={30} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
