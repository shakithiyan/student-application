import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, School, BookOpen, Hash, Phone, CreditCard, Send, CheckCircle2 } from 'lucide-react';
import { STREAMS, BATCHES, GENDERS, StudentRegistration } from '../types';
import { cn } from '../lib/utils';

interface RegistrationFormProps {
  onSubmit: (data: Omit<StudentRegistration, 'id' | 'status' | 'createdAt'>) => Promise<unknown>;
}

export default function RegistrationForm({ onSubmit }: RegistrationFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    stream: STREAMS[0],
    batch: BATCHES[2], // Default to 2026
    schoolName: '',
    gender: 'male' as 'male' | 'female',
    contactNumber: '',
    nicNumber: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleGenderChange = (gender: 'male' | 'female') => {
    setFormData(prev => ({ ...prev, gender }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await onSubmit(formData);
      setIsSuccess(true);
    } catch (error) {
      console.error('Submission failed:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-8 rounded-3xl shadow-xl text-center max-w-md mx-auto border border-blue-100"
      >
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-12 h-12 text-green-600" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Registration Successful!</h2>
        <p className="text-gray-600 mb-8">
          Thank you for registering for KMBUSA EXAMS 2026. Your application is currently pending approval.
        </p>
        <button 
          onClick={() => setIsSuccess(false)}
          className="w-full py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-all shadow-lg active:scale-95"
        >
          Register Another Student
        </button>
      </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8 md:p-10"
    >
      <div className="flex justify-between items-center mb-10">
        <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-3">
          <span className="w-2 h-8 bg-blue-600 rounded-full"></span>
          Student Application
        </h2>
        <span className="text-[10px] font-black text-blue-600 bg-blue-50 px-3 py-1 rounded-full uppercase tracking-widest border border-blue-100">Step 1 of 1</span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
          {/* Full Name */}
          <div className="col-span-full space-y-1.5">
            <label className="block text-[10px] font-black text-slate-500 tracking-[0.2em] uppercase ml-1">
              Full Name
            </label>
            <div className="relative group">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
              <input
                required
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleChange}
                placeholder="Enter student's full name"
                className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all placeholder:text-slate-300 font-medium"
              />
            </div>
          </div>

          {/* School Name */}
          <div className="col-span-full space-y-1.5">
            <label className="block text-[10px] font-black text-slate-500 tracking-[0.2em] uppercase ml-1">
              School Name
            </label>
            <div className="relative group">
              <School className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
              <input
                required
                type="text"
                name="schoolName"
                value={formData.schoolName}
                onChange={handleChange}
                placeholder="Current attending school"
                className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all placeholder:text-slate-300 font-medium"
              />
            </div>
          </div>

          {/* Stream */}
          <div className="space-y-1.5">
            <label className="block text-[10px] font-black text-slate-500 tracking-[0.2em] uppercase ml-1">
              Stream
            </label>
            <select
              name="stream"
              value={formData.stream}
              onChange={handleChange}
              className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all cursor-pointer font-semibold text-slate-700"
            >
              {STREAMS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          {/* Batch */}
          <div className="space-y-1.5">
            <label className="block text-[10px] font-black text-slate-500 tracking-[0.2em] uppercase ml-1">
              Batch
            </label>
            <select
              name="batch"
              value={formData.batch}
              onChange={handleChange}
              className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all cursor-pointer font-semibold text-slate-700"
            >
              {BATCHES.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>

          {/* Gender */}
          <div className="space-y-1.5">
            <label className="block text-[10px] font-black text-slate-500 tracking-[0.2em] uppercase ml-1">Gender</label>
            <div className="flex gap-2 p-1 bg-slate-100 rounded-2xl border border-slate-200">
              {GENDERS.map(g => (
                <button
                  key={g}
                  type="button"
                  onClick={() => handleGenderChange(g)}
                  className={cn(
                    "flex-1 py-2.5 px-4 rounded-xl capitalize text-xs font-black transition-all tracking-tight",
                    formData.gender === g 
                      ? "bg-white text-blue-600 shadow-sm ring-1 ring-slate-200" 
                      : "text-slate-400 hover:text-slate-600"
                  )}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          {/* NIC Number */}
          <div className="space-y-1.5">
            <label className="block text-[10px] font-black text-slate-500 tracking-[0.2em] uppercase ml-1">
              NIC Number
            </label>
            <input
              required
              type="text"
              name="nicNumber"
              value={formData.nicNumber}
              onChange={handleChange}
              placeholder="e.g. 200512345678"
              className="w-full px-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all placeholder:text-slate-300 font-medium font-mono"
            />
          </div>

          {/* Contact Number */}
          <div className="col-span-full space-y-1.5">
            <label className="block text-[10px] font-black text-slate-500 tracking-[0.2em] uppercase ml-1">
              Contact Number
            </label>
            <div className="relative group">
              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
              <input
                required
                type="tel"
                name="contactNumber"
                value={formData.contactNumber}
                onChange={handleChange}
                placeholder="077 123 4567"
                className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all placeholder:text-slate-300 font-medium font-mono"
              />
            </div>
          </div>
        </div>

        <button
          disabled={isSubmitting}
          type="submit"
          className={cn(
            "w-full py-5 px-6 rounded-2xl font-black text-sm uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all shadow-xl active:scale-[0.98]",
            isSubmitting 
              ? "bg-slate-200 text-slate-400 cursor-not-allowed" 
              : "bg-blue-600 hover:bg-blue-700 text-white shadow-blue-200"
          )}
        >
          {isSubmitting ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <>
              Submit Registration <Send className="w-4 h-4" />
            </>
          )}
        </button>
      </form>
    </motion.div>
  );
}
