import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, 
  X, 
  MapPin, 
  Mail, 
  Phone, 
  Facebook, 
  Instagram, 
  ShieldCheck, 
  Lock,
  GraduationCap,
  Calendar,
  Users,
  ChevronRight,
  Info,
  BarChart3
} from 'lucide-react';
import Intro from './components/Intro';
import RegistrationForm from './components/RegistrationForm';
import AdminPanel from './components/AdminPanel';
import { StudentRegistration } from './types';
import { registerStudent, subscribeToRegistrations, testConnection } from './firebase';
import { cn } from './lib/utils';

// Hardcoded pin for the requested admin security feature
const ADMIN_PIN = "2026"; 

export default function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [registrations, setRegistrations] = useState<StudentRegistration[]>([]);
  const [pinEntry, setPinEntry] = useState('');
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [pinError, setPinError] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    testConnection();
    if (!isAdminMode) return;
    const unsubscribe = subscribeToRegistrations((data) => {
      setRegistrations(data);
    });
    return () => unsubscribe();
  }, [isAdminMode]);

  const handleAdminAccess = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinEntry === ADMIN_PIN) {
      setIsAdminMode(true);
      setIsPinModalOpen(false);
      setPinError(false);
      setPinEntry('');
    } else {
      setPinError(true);
    }
  };

  if (showIntro) {
    return <Intro onComplete={() => setShowIntro(false)} />;
  }

  if (isAdminMode) {
    return <AdminPanel registrations={registrations} onLogout={() => setIsAdminMode(false)} />;
  }

  return (
    <div className="h-screen w-screen bg-slate-50 flex overflow-hidden font-sans text-slate-800">
      {/* Sidebar */}
      <aside className="hidden lg:flex w-80 bg-blue-900 flex-col p-8 text-white shrink-0 shadow-2xl z-10">
        <div className="flex flex-col items-center mb-10">
          <motion.div 
            initial={{ rotate: 0 }}
            animate={{ rotate: 3 }}
            className="w-24 h-24 bg-white rounded-2xl flex items-center justify-center shadow-lg mb-6 group cursor-pointer border-2 border-white/20 p-4"
          >
            <GraduationCap className="w-12 h-12 text-blue-900 group-hover:scale-110 transition-transform" />
          </motion.div>
          <h1 className="text-3xl font-black tracking-tighter">KMBUSA</h1>
          <p className="text-xs text-blue-200 mt-2 text-center leading-relaxed font-medium">
            Kilinochchi Maths Bio University Students' Association<br/>
            <span className="opacity-50 font-mono">ESTABLISHED 2024</span>
          </p>
        </div>

        <nav className="space-y-4 flex-1">
          <div className="p-4 hover:bg-white/5 rounded-xl transition-colors group cursor-pointer" onClick={() => {
            const el = document.getElementById('register');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}>
            <h3 className="text-[10px] font-bold text-blue-300 uppercase tracking-[0.2em] mb-1">Join Now</h3>
            <p className="text-sm font-semibold">Student Application</p>
          </div>
          
          <a href="#about" className="block p-4 hover:bg-white/5 rounded-xl transition-colors group">
            <h3 className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mb-1 group-hover:text-blue-300">Information</h3>
            <p className="text-sm opacity-80 group-hover:opacity-100 font-medium">About KMBUSA</p>
          </a>

          <div className="p-4 bg-white/10 rounded-xl border border-white/10 backdrop-blur-sm">
            <h3 className="text-[10px] font-bold text-blue-300 uppercase tracking-widest mb-1">Academic Programs</h3>
            <p className="text-sm font-semibold">A/L Pilot Exams & O/L Seminars</p>
          </div>

          <div className="p-4 hover:bg-white/5 rounded-xl transition-colors group">
            <h3 className="text-[10px] font-bold text-orange-400 uppercase tracking-widest mb-1 group-hover:text-orange-300">New Feature</h3>
            <p className="text-sm opacity-80 group-hover:opacity-100 font-medium">Career Guidance Portal</p>
          </div>
        </nav>

        <div className="pt-6 border-t border-white/10">
          <button 
            onClick={() => setIsPinModalOpen(true)}
            className="w-full flex items-center justify-between p-3 bg-white/5 hover:bg-white/10 rounded-xl border border-white/5 transition-all group"
          >
            <div className="flex items-center gap-3">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-bold tracking-wider">ADMIN PORTAL</span>
            </div>
            <ChevronRight className="w-4 h-4 text-white/30 group-hover:translate-x-1 transition-transform" />
          </button>
          <div className="mt-4 flex items-center gap-3 text-[10px] uppercase font-bold tracking-widest text-blue-300/50">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(74,222,128,0.5)]"></div>
            <span>System Online • KMBUSA</span>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-y-auto bg-slate-50 relative">
        {/* Mobile Header (Only visible on small/med) */}
        <header className="lg:hidden h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-6 h-6 text-blue-600" />
            <span className="font-black text-xl tracking-tighter text-blue-950">KMBUSA</span>
          </div>
          <button 
            onClick={() => setMobileMenuOpen(true)}
            className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <Menu className="w-6 h-6" />
          </button>
        </header>

        <div className="p-6 md:p-10 lg:p-12 max-w-[1400px] mx-auto w-full flex flex-col gap-10">
          {/* Page Header */}
          <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="border-l-4 border-blue-600 pl-6 py-1">
              <h2 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tighter leading-none">Exam Registration</h2>
              <p className="text-slate-500 font-medium mt-2">Free online portal for Kilinochchi's future leaders</p>
            </div>
            <div className="hidden md:flex gap-4">
               {/* Stats or breadcrumbs could go here */}
            </div>
          </header>

          {/* Body Content */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
            {/* Form Column */}
            <div className="xl:col-span-7">
              <div id="register">
                <RegistrationForm onSubmit={registerStudent} />
              </div>
            </div>

            {/* Sidebar Column (Landing page specific) */}
            <div className="xl:col-span-5 flex flex-col gap-8">
              {/* Mission/Guideline Card */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="bg-white rounded-3xl shadow-lg border border-slate-100 p-8"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                    <GraduationCap className="w-5 h-5 text-blue-600" />
                  </div>
                  <h3 className="text-sm font-black text-slate-900 tracking-widest uppercase">Our Mission</h3>
                </div>
                
                <p className="text-slate-600 text-sm leading-relaxed mb-6 font-medium">
                  KMBUSA is dedicated to uplifting the standards of education in the Kilinochchi district. We provide academic support, mentorship, and resources for Math and Bio stream students.
                </p>

                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                      <GraduationCap className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-900 uppercase tracking-tighter">Pilot Exams</p>
                      <p className="text-[11px] text-slate-500 font-medium">Real-world exam simulations for all A/L batches.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                      <Users className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-900 uppercase tracking-tighter">O/L Seminars</p>
                      <p className="text-[11px] text-slate-500 font-medium">Focused workshops for Grade 11 students.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center shrink-0">
                      <Info className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-xs font-black text-slate-900 uppercase tracking-tighter">Career Guidance</p>
                      <p className="text-[11px] text-slate-500 font-medium">Mentorship for A/L result holders on courses & universities.</p>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Info/About Card */}
              <motion.div 
                id="about"
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="bg-slate-900 rounded-3xl shadow-2xl p-8 text-white relative overflow-hidden group"
              >
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                  <Info className="w-24 h-24" />
                </div>
                <h3 className="text-xl font-black mb-4 relative z-10 tracking-tight">Important Notice</h3>
                <p className="text-blue-100/70 text-sm leading-relaxed mb-6 font-medium relative z-10">
                  Applications for KMBUSA programs are evaluated on a first-come-first-serve basis. Please ensure all details match your NIC.
                </p>
                <div className="space-y-4 relative z-10">
                  <div className="flex items-center gap-4">
                     <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center">
                       <Phone className="w-4 h-4" />
                     </div>
                     <div>
                       <p className="text-[10px] text-blue-400 font-bold uppercase tracking-widest leading-tight">Iynkaran (President 2026 KMBUSA)</p>
                       <p className="font-bold text-lg">+94 77 624 0570</p>
                     </div>
                  </div>
                  <div className="flex items-center gap-4">
                     <div className="w-10 h-10 rounded-xl bg-blue-500 flex items-center justify-center">
                       <Phone className="w-4 h-4" />
                     </div>
                     <div>
                       <p className="text-[10px] text-blue-300 font-bold uppercase tracking-widest leading-tight">Sarangan (Secretary 2026 KMBUSA)</p>
                       <p className="font-bold text-lg">+94 76 699 0842</p>
                     </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Simple Footer */}
        <footer className="mt-auto px-6 py-10 border-t border-slate-200 bg-white">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-slate-400 text-xs font-bold tracking-tight">© 2026 KMBUSA SYSTEM • SECURE PORTAL</p>
            <div className="flex gap-6 text-slate-400">
               <Facebook className="w-4 h-4 hover:text-blue-600 cursor-pointer transition-colors" />
               <Instagram className="w-4 h-4 hover:text-blue-600 cursor-pointer transition-colors" />
               <Mail className="w-4 h-4 hover:text-blue-600 cursor-pointer transition-colors" />
            </div>
          </div>
        </footer>
      </main>

      {/* Admin Pin Modal */}
      <AnimatePresence>
        {isPinModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsPinModalOpen(false)}
              className="absolute inset-0 bg-blue-950/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white w-full max-w-sm p-8 rounded-3xl shadow-2xl"
            >
              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Lock className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900">Admin Authentication</h3>
                <p className="text-gray-500">Please enter your management pin.</p>
              </div>

              <form onSubmit={handleAdminAccess} className="space-y-4">
                <div className="relative">
                  <input 
                    type="password"
                    autoFocus
                    value={pinEntry}
                    onChange={(e) => {
                      setPinEntry(e.target.value);
                      setPinError(false);
                    }}
                    placeholder="Enter Security Pin"
                    className={cn(
                      "w-full px-4 py-4 bg-gray-50 border rounded-2xl text-center text-2xl font-bold tracking-[1em] outline-none transition-all",
                      pinError ? "border-red-500 ring-4 ring-red-50" : "border-gray-200 focus:ring-4 focus:ring-blue-100"
                    )}
                  />
                  {pinError && (
                    <motion.p 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-red-500 text-xs font-bold mt-2 text-center"
                    >
                      Incorrect pin. Please try again.
                    </motion.p>
                  )}
                </div>
                <button 
                  type="submit"
                  className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 active:scale-95"
                >
                  Verify & Access
                </button>
              </form>
              <p className="text-[10px] text-gray-400 text-center mt-6 uppercase tracking-widest font-bold">
                KMBUSA MANAGEMENT SYSTEM
              </p>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Mobile Nav Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="fixed inset-0 z-50 bg-white md:hidden p-8 flex flex-col"
          >
            <div className="flex justify-between items-center mb-12">
              <span className="text-2xl font-black tracking-tighter text-blue-900">KMBUSA</span>
              <button onClick={() => setMobileMenuOpen(false)} className="p-2 bg-gray-100 rounded-xl"><X /></button>
            </div>
            <div className="flex flex-col gap-6">
              <a href="#about" onClick={() => setMobileMenuOpen(false)} className="text-3xl font-bold text-gray-900">About</a>
              <a href="#register" onClick={() => setMobileMenuOpen(false)} className="text-3xl font-bold text-gray-900">Apply Now</a>
              <button 
                onClick={() => {
                  setMobileMenuOpen(false);
                  setIsPinModalOpen(true);
                }} 
                className="w-full py-6 bg-blue-50 text-blue-700 rounded-3xl text-xl font-bold flex items-center justify-center gap-3"
              >
                <ShieldCheck className="w-6 h-6" /> Admin Portal
              </button>
            </div>
            <div className="mt-auto pt-12 border-t border-gray-100">
               <p className="text-sm text-gray-400 font-medium italic">Empowering Kilinochchi since 2024</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
